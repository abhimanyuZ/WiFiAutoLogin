cd ~/Desktop;
python wifi.py;
exit